<?php

header("Content-type: text/html; charset=utf-8");

for ($j = 0; $j <= 10; $j+=2){
    
        echo "<br/>O Valor de J é: $j";
}

?>