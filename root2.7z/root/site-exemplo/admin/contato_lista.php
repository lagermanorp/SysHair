<?php
    $tituloPagina = "Dashboard";
    include_once("inc/topo.php");

?>

<!-- Contato - Inicio do código personalizado -->
    <h1 class="h2">Contatos</h1>

<table class="table table-striped table-sm">
    <thead>
        <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Telefone</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>AAA</td>
            <td>BBB</td>
            <td>CCC</td>
        </tr>
    </tbody>

</table>