<?php

    require_once(__DIR__ . "/../inc/conexao.php");
    require_once(__DIR__ . "/../model/contato.model.php");

    class ContatosDao extends Conexao{
        public $Mensagem;
        //Método para inserir registro
        public function Inserir($contato){
            
            $sql = "INSERT INTO contatos (nome, email, telefone, mensagem)
                VALUES (?,?,?,?)";
            
            $parametros = array($contato->Nome, $contato->Email, $contato->Telefone, $contato->Mensagem);
            
            try{
                $comando = $this->prepare($sql);
                $comando->execute($parametros);
                return true;
            }
            catch (PDOException $ex)
            {
                $this->Mensagem = "Erro ao inserir o registro" . $ex->getMessage();
                return false;
            }
        }
        //Método para alterar registro
        public function Alterar($contato){
            
            
        }
        //Método para listar todos os registros
        public function ListarTudo(){
            
            
        }
        //Método para pesquisar por um registro específico
        public function BuscarPorId($id){
            
            
        }
        //Método para excluir um registro específico
        public function Excluir($id){
            
            
        }
    
    }


?>