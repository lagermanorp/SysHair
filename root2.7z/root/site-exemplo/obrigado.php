<?php

    $TituloPagina = "Home";

     // Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");

?>


    <h1>E-MAIL ENVIADO COM SUCESSO, AGRADECEMOS PELO SEU CONTATO!!!</h1>


<?php

// Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/rodape.php");
?>