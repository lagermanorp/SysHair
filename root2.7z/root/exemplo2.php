<?php

    header("Content-type: text/html; charset=utf-8");

   echo "Olá, ".$_GET["nome"]."! Este é meu primeiro PHP.";

?>