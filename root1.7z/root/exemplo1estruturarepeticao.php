<?php

header("Content-type: text/html; charset=utf-8");

for ($x = 1; $x <= 10; $x++){
    
        echo "<br/>O Valor de X é: $x";
}

?>