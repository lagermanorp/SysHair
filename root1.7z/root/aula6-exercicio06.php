<?php

    header("Content-type: text/html; charset=utf-8");

    $maior = 0;
    $menor = 0;
