<?php
    $tituloPagina = "Home";

    // Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");
?>

    <h1>EMPRESA</h1>
    <p>Silvio Santos Ipsum É bom ou não é? Ha hai. Bem boladoam, bem boladoam. Bem gozadoam. Mah é a porta da esperçamm. Eu só acreditoammmm.... Vendoammmm. Valendo um milhão de reaisammm. Ha haeeee. Hi hi. Ma quem quer dinheiroam? Patrciaaammmm... Luiz Ricardouaaammmmmm. Ma vejam só, vejam só.</p>

 <p>Um, dois três, quatro, PIM, entendeuam? Mah você mora com o papai ou com a mamãem? Estamos em ritmo de festamm. Ma! Ao adquirir o carnê do Baú, você estará concorrendo a um prêmio de cem mil reaisam. Eu não queria perguntar isso publicamenteam, ma vou perguntar. Carla, você tem o ensino fundamentauam? Ha haeeee. Hi hi. Ha haeeee. Hi hi. É por sua conta e riscoamm?</p>

 <p>Mah é a porta da esperçamm. É fácil ou no é? É bom ou não é? Mah é a porta da esperçamm. É dinheiro ou não é? É fácil ou no é? É dinheiro ou não é? Ma tem ou no tem o celular do milhãouamm? Valendo um milhão de reaisammm.</p>

 <p>Vem pra lá, mah você vai pra cá. Agora vai, agora vem pra lamm. Ma você, topa ou no topamm. Eu só acreditoammmm.... Vendoammmm. Valendo um milhão de reaisammm. Mah ooooee vem pra cá. Vem pra cá. O arriscam tuduam, valendo um milhão de reaisuam. Você veio da caravana de ondeammm? Um, dois três, quatro, PIM, entendeuam? É fácil ou no é? Mah é a porta da esperçamm. Ma o Silvio Santos Ipsum é muitoam interesanteam. Com ele ma você vai gerar textuans ha haae.</p>

 <p>Ma você, topa ou no topamm. Ma o Silvio Santos Ipsum é muitoam interesanteam. Com ele ma você vai gerar textuans ha haae. Mah é a porta da esperçamm. O prêmio é em barras de ouro, que vale mais que dinheiroam. Valendo um milhão de reaisammm. O arriscam tuduam, valendo um milhão de reaisuam. Um, dois três, quatro, PIM, entendeuam? No duro? Ma não existem mulher feiam, existem mulher que no conhece os produtos Jequitiamm. Qual é a musicamm? Ma voc está certo dissoam? Ma você, topa ou no topamm. Ma vale dérreaisam?</p>


<?php
    // Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/rodape.php");
?>