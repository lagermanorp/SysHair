<?php

    header("Content-type: text/html; charset=utf-8");

    echo("Olá, o meu nome é Luiz Antônio Germano");

?>