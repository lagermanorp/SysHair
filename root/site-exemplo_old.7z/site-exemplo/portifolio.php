<?php
    $tituloPagina = "Home";

    // Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/topo.php");
?>

    <h1>PORTIFOLIO</h1>

    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tortor ante, lobortis eget interdum sit amet, ultrices nec risus. Donec scelerisque elit eu odio gravida suscipit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam venenatis eros sem, at porta elit interdum non. Integer tincidunt mi quis sollicitudin vulputate. Vivamus euismod, odio ac convallis accumsan, turpis velit tempor metus, vitae varius purus orci dignissim sapien. Suspendisse viverra velit sed diam aliquet, ut tempor ex congue. Curabitur id lacinia odio. Sed elementum nisi a aliquet porta. Proin sed est et ex laoreet ornare. Nulla elementum a sem vitae iaculis.</p>

<p>Duis magna dolor, posuere eu dolor maximus, lacinia rutrum mi. Integer convallis, metus blandit facilisis accumsan, turpis sem pulvinar ligula, vitae congue urna justo cursus eros. Aenean dui nulla, rhoncus eget leo sit amet, ornare efficitur nisl. Sed tincidunt dignissim aliquet. Vivamus sagittis odio eget tristique pretium. Cras venenatis purus et augue ullamcorper interdum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam eleifend, purus et iaculis semper, eros velit sodales arcu, finibus pharetra felis justo vel ligula. Nam placerat nisi nulla, sed fermentum libero sollicitudin vel. Donec sit amet accumsan magna, eu luctus augue. Sed in viverra felis. Maecenas scelerisque ultricies suscipit. Nulla id velit commodo, suscipit magna non, pretium ante. Proin a purus quis nisl luctus molestie.</p>

<p>Mauris sagittis orci id enim facilisis malesuada. Etiam in tincidunt leo. Sed elementum iaculis orci, vitae facilisis augue blandit eget. Proin eu tristique eros, vel convallis leo. Phasellus dignissim quam vitae tincidunt luctus. Nulla consequat posuere nisl eu dictum. Vivamus fermentum diam et enim aliquam condimentum. Donec vulputate nisl tortor, sit amet feugiat mi posuere non. Vivamus in tortor a tellus fringilla maximus vitae in libero. Donec mauris nunc, rhoncus et ante eu, eleifend volutpat felis.</p>

<?php
    // Diretivas de Inclusão: include, include_once, require, require_once
    include_once("inc/rodape.php");
?>