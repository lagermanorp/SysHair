<?php
    $tituloPagina = "Dashboard";
    include_once("inc/topo.php");

?>

<!-- Portifolio - Inicio do código personalizado -->
   

<form>
    
    <legend>Formulário de Cadastro</legend>
    <h4>Título:</h4>
    <input type="text" id="txtTitulo" name="Titulo" size="135" />
    <h4>Imagem:</h4>
    <input type="file" id="arqImagem" name="Imagem" size="135" />
    <h4>Link:</h4>
    <input type="url" id="txtLinkExterno" name="LinkExterno" size="135" />
    <h4>Descrição:</h4>
    <textarea id="txtDescricao" name="Descricao" rows="15" cols="135"></textarea>
        
    <div>
        <button type="submit">Salvar</button>
    </div>
    
</form>


<!-- Portifolio - Final do código personalizado -->

<?php
    include_once("inc/rodape.php");
?>