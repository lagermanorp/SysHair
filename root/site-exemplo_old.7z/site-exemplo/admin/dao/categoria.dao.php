<?php 

    require_once(__DIR__ . "/../inc/conexao.php");
    require_once(__DIR__ . "/../model/categoria.model.php");

    class CategoriasDao extends Conexao {
        public $Mensagem;
        //Método para inserir registro
        public function Inserir($categoria){
            
            $sql = "INSERT INTO categoria (titulo)
                VALUES (?)";
            
            $parametros = array($categoria->Titulo);
            
            try{
                $comando = $this->prepare($sql);
                $comando->execute($parametros);
                return true;
            }
            catch (PDOException $ex)
            {
                $this->Mensagem = "Erro ao inserir o registro" . $ex->getMessage();
                return false;
            }
        }

    
         //Método para alterar registro
        public function Alterar($categoria){
    
    
    }

      //Método para listar todos os registros
        public function ListarTudo(){
            $sql = "SELECT * FROM categoria";
            
            try {
                $comando = $this->prepare($sql);
                $resultado = $comando->execute();
                $registros = $comando->fetchAll(PDO::FETCH_ASSOC);
                foreach($registros as &$reg){
                    $item = new Categoria();
                    $item->Id = $reg["id"];
                    $item->Titulo = $reg["titulo"];
                    $retorno[]=$item;
                }
            }
            catch (PDOException $ex)
            {
                $this->Mensagem = "Erro ao listar: " . $ex->getMessage();
            }
            return $retorno;    
        }    

        //Método para excluir um registro específico
        public function Excluir($id){
            
            
        }


}






?>