<?php
    $tituloPagina = "Dashboard";
    include_once("inc/topo.php");

?>

<!-- Portifolio - Inicio do código personalizado -->
    <h1 class="h2">Portifolio</h1>

<div>
<a href="portifolio_form.php" class="btn btn-primary">
    <span data-feather="plus-circle"></span>
    Incluir</a>
</div>

<table class="table table-striped table-sm">
    <thead>
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Descrição</th>
            <th>Imagem</th>
            <th>Categoria</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>AAA</td>
            <td>BBB</td>
            <td>CCC</td>
        </tr>
    </tbody>

</table>















<!-- Portifolio - Final do código personalizado -->

<?php
    include_once("inc/rodape.php");
?>