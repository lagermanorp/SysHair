<?php

    class Categoria {
        
        public $Id;
        public $Titulo;
        
        
    }






?>