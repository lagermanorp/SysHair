<?php

    class Contato {
        
        public $Id;
        public $Nome;
        public $Telefone;
        public $Email;
        public $Mensagem;
        
        
        
    }




?>