 </main>
            <footer>
                <div>Copyright &copy; 2019 - Todos os Direitos Reservados</div>
                <div>Acesse nossas Redes Sociais</div>    
                <nav>
                   <ul>
                        <li><a href="empresa.php">Empresa</a></li>
                        <li><a href="portifolio.php">Portfolio</a></li>
                        <li><a href="contato.php">Contato</a></li>
                    </ul>
                </nav>
            </footer>
        </div>
    </body>
</html>