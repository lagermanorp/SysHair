<?php

    class Portifolio {
        
        public $Id;
        public $Titulo;
        public $Descricao;
        public $Imagem;
        public $Id_categoria;
        public $Titulo_categoria;
        
        
    }




?>