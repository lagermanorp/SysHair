<?php 
    include_once(__DIR__ . "/dao/categorias.dao.php");
    
    //Crio uma instancia da Model
    $categoria = new Categoria();

    $categoria->Titulo = $_POST["txtTitulo"];
    //Crio a instancia da DAO
    $categoriasDAO = new CategoriasDAO();
    //Invoco o método de inserção da DAO
    $sucesso = $categoriasDAO->Inserir($categoria);

    if ($sucesso) {
        
        header("location: categoria_lista.php");
        exit();
    }

    echo "Ocorreu um erro na Operação: " . $categoriasDAO->Mensagem;


?>