<?php
    $tituloPagina = "Dashboard";
    include_once("inc/topo.php");

?>

<!-- Empresa - Inicio do código personalizado -->
    <h1 class="h2">Empresa</h1>

<form>
    <textarea class="form-control" rows="20" cols="100" id="txtEmpresa" name="txtEmpresa"></textarea>
    
    <button class="btn btn-primary">
        <span data-fether="save"></span>
    Salvar</button>
            
</form>














<!-- Empresa - Inicio do código personalizado -->

<?php

    include_once("inc/rodape.php");

?>