<?php

    require_once(__DIR__ . "/../inc/conexao.php");
    require_once(__DIR__ . "/../model/portifolio.model.php");

    class PortifoliosDao extends Conexao {
        public $Mensagem;
        //Método para inserir registro
        public function Inserir($portifolio) {
            
            $sql = "INSERT INTO portifolio (titulo, descricao, imagem, id_categoria)
            values (?,?,?,?)";
            
            $parametros = array($portifolio->Titulo, $portifolio->descricao, $portifolio->imagem, $portifolio->id_categoria);
            
            try {
                $comando = $this->prepare($sql);
                $comando->execute($parametros);
                return true;
            }
            catch (PDOException $ex)
            {
                $this->Mensagem = "Erro ao inserir o registro" . $ex->getMessage();
                return false;
            }
            
        }
        
        //Método para alterar registro
        public function Alterar($portifolio) {
            
            
        }
        
        //Método para listar todos os registros
        public function ListarTudo() {
            $sql = "SELECT * FROM portifolio";
            $retorno = array();
            try {
                $comando = $this->prepare($sql);
                $resultado = $comando->execute();
                $registros = $comando->fetchAll(PDO::FETCH_ASSOC);
                foreach($registros as &$reg) {
                    $item = new Portifolio();
                    $item->Id = $reg["id"];
                    $item->Titulo = $reg["titulo"];
                    $item->Descricao = $reg["descricao"];
                    $item->Imagem = $reg["imagem"];
                    $item->Id_categoria = $reg["id_categoria"];
                    $retorno[] = $item;
                }
            }
            catch (PDOException $ex)
            {
                $this->Mensagem = "Erro ao listar: " . $ex->getMessage();
            }
            return $retorno;
        }
        
         //Método para excluir um registro específico
        public function Excluir($id){
            
            
        }
        
    }





?>