<!doctype>
<html>
    <head>
    
        <meta charset="utf-8" />
    
    </head>

    <body>
        <form action="autenticacao.php" method="POST">
            <div>
                <label>email</label>
                    <input type="email" id="email" name="email"><br>
            </div>
            <br>
            <div>
                <label>Senha</label>
                    <input type="password" id="senha" name="senha"><br>
            </div>
            <br>
            <div>
                    <input type="submit" value="Entrar">
            </div>
        </form>
    </body>
</html>